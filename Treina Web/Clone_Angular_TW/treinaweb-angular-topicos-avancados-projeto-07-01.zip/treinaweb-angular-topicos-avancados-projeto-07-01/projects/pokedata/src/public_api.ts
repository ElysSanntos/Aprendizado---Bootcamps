/*
 * Public API Surface of pokedata
 */

export * from './lib/pokedata.service';
export * from './lib/pokedata.component';
export * from './lib/pokedata.module';
export * from './lib/services/pokeapi.service';