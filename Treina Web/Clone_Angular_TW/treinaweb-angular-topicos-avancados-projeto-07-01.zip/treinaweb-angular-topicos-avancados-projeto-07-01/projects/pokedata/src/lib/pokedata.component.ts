import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-pokedata',
  template: `
    <p>
      pokedata works!
    </p>
  `,
  styles: []
})
export class PokedataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
