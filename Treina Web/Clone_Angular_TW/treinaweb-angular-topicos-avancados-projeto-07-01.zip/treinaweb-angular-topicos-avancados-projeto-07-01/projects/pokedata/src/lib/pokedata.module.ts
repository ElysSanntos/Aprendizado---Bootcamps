import { NgModule } from '@angular/core';
import { PokedataComponent } from './pokedata.component';

@NgModule({
  imports: [
  ],
  declarations: [PokedataComponent],
  exports: [PokedataComponent]
})
export class PokedataModule { }
