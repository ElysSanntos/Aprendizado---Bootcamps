import { RollOnScrollDirective } from './roll-on-scroll.directive';

describe('RollOnScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new RollOnScrollDirective();
    expect(directive).toBeTruthy();
  });
});
