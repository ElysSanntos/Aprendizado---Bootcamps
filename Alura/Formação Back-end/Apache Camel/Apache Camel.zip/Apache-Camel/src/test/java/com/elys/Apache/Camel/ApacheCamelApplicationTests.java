package com.elys.Apache.Camel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApacheCamelApplicationTests {

	@Test
	void contextLoads() {
	}

}
