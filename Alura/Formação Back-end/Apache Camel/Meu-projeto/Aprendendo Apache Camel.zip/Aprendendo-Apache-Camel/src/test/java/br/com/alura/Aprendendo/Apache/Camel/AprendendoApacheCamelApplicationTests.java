package br.com.alura.Aprendendo.Apache.Camel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AprendendoApacheCamelApplicationTests {

	@Test
	void contextLoads() {
	}

}
