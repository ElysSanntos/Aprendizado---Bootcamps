package br.com.elysantos.Aprendizado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AprendizadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
